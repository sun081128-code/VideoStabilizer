import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// 签名信息放在工程根目录的 keystore.properties（不要提交到 git）
// 文件不存在时不配签名，release 产物是 app-release-unsigned.apk，装不上手机
val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties().apply {
    if (keystorePropsFile.exists()) {
        FileInputStream(keystorePropsFile).use { load(it) }
    }
}
val hasSigningConfig = keystorePropsFile.exists()

android {
    namespace = "com.example.videostab"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.videostab"
        minSdk = 24
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"

        // OpenCV 只发布 arm 架构的 so，模拟器请用 arm64 镜像或 x86_64 手动编译版
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        if (hasSigningConfig) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasSigningConfig) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    // 想按 CPU 架构拆包（每个 APK 体积减半）就打开这段，
    // 产物会变成 app-arm64-v8a-release.apk / app-armeabi-v7a-release.apk
    // splits {
    //     abi {
    //         isEnable = true
    //         reset()
    //         include("arm64-v8a", "armeabi-v7a")
    //         isUniversalApk = false
    //     }
    // }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    packaging {
        resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // OpenCV 4.9.0 起发布到 Maven Central，4.10.0 对应 AAR 内含 armeabi-v7a / arm64-v8a 的 .so
    implementation(project(":opencv"))

    // ------------------------------------------------------------------
    // 如果上面这行 sync 失败（找不到 org.opencv:opencv-android），改用手动导入：
    //
    // 1) 下载 opencv-4.10.0-android-sdk.zip，解压得到 OpenCV-android-sdk/
    // 2) 把 OpenCV-android-sdk/sdk 整个目录拷到工程根目录，改名为 opencv
    // 3) settings.gradle.kts 里加一行：include(":opencv")
    // 4) 删掉上面的 implementation("org.opencv:opencv-android:4.10.0")
    //    换成：  implementation(project(":opencv"))
    //
    // 若 sdk 目录里的 build.gradle 是旧版（没有 namespace / compileSdk 太老），
    // 在 opencv/build.gradle 的 android{} 里补上：
    //     namespace "org.opencv"
    //     compileSdk 33
    // 并在 opencv/src/main/AndroidManifest.xml 里删掉 package="org.opencv" 属性。
    // ------------------------------------------------------------------
}
