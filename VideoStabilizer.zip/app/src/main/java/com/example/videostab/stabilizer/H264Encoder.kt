package com.example.videostab.stabilizer

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import java.nio.ByteBuffer

/**
 * MediaCodec 的 H.264 编码封装：吃 OpenCV 的 BGR Mat，吐 H.264 码流。
 *
 * 走 byte-buffer 输入（不是 Surface 输入），所以要把 BGR 转成 YUV420。
 * 注意 COLOR_FormatYUV420SemiPlanar 在 Android 上的定义是 NV12（Y 平面 + UV 交织）。
 */
class H264Encoder(
    private val width: Int,
    private val height: Int,
    private val frameRate: Int,
    private val bitRate: Int
) {
    var onOutputFormat: ((MediaFormat) -> Unit)? = null
    var onSample: ((ByteBuffer, MediaCodec.BufferInfo) -> Unit)? = null

    private var codec: MediaCodec? = null
    private var colorFormat = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
    private val bufferInfo = MediaCodec.BufferInfo()
    private var lastPtsUs = 0L
    private var sawEos = false

    private val ySize = width * height
    private val uvSize = ySize / 4
    private val i420 = ByteArray(ySize + uvSize * 2)
    private val outBytes = ByteArray(ySize + uvSize * 2)
    private val yuvMat = Mat(height * 3 / 2, width, CvType.CV_8UC1)

    fun start() {
        val (info, fmt) = selectEncoder()
        colorFormat = fmt
        val format = MediaFormat.createVideoFormat(MIME, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, fmt)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(
                MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
            )
        }
        val c = MediaCodec.createByCodecName(info.name)
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        c.start()
        codec = c
    }

    /**
     * 送一帧并顺手把已产出的码流排空（编码器内部 buffer 有限，必须边送边取）。
     */
    fun queueFrame(bgr: Mat, ptsUs: Long) {
        val c = codec ?: return
        fillYuv(bgr)
        var guard = 0
        while (guard++ < 300) {
            val index = c.dequeueInputBuffer(10_000)
            if (index >= 0) {
                val buffer = c.getInputBuffer(index)
                if (buffer != null) {
                    buffer.clear()
                    buffer.put(outBytes, 0, outBytes.size)
                    c.queueInputBuffer(index, 0, outBytes.size, ptsUs, 0)
                    lastPtsUs = ptsUs
                    drain()
                    return
                }
            }
            drain()
        }
        throw IllegalStateException("编码器输入缓冲长时间不可用")
    }

    /** 送 EOS 并把残余码流取干净 */
    fun finish() {
        val c = codec ?: return
        var guard = 0
        while (guard++ < 100) {
            val index = c.dequeueInputBuffer(50_000)
            if (index >= 0) {
                c.queueInputBuffer(
                    index, 0, 0, lastPtsUs + 1_000,
                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                )
                break
            }
            drain()
        }
        guard = 0
        while (!sawEos && guard++ < 400) {
            drain()
            if (!sawEos) Thread.sleep(5)
        }
    }

    fun release() {
        try {
            codec?.stop()
        } catch (_: Throwable) {
        }
        try {
            codec?.release()
        } catch (_: Throwable) {
        }
        codec = null
        yuvMat.release()
    }

    // ---------------------------------------------------------------- internal

    private fun drain() {
        val c = codec ?: return
        while (true) {
            val index = c.dequeueOutputBuffer(bufferInfo, 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onOutputFormat?.invoke(c.outputFormat)
                index >= 0 -> {
                    val buffer = c.getOutputBuffer(index)
                    if (buffer != null && bufferInfo.size > 0) {
                        buffer.position(bufferInfo.offset)
                        buffer.limit(bufferInfo.offset + bufferInfo.size)
                        onSample?.invoke(buffer, bufferInfo)
                    }
                    c.releaseOutputBuffer(index, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        sawEos = true
                        return
                    }
                }
                else -> return
            }
        }
    }

    private fun fillYuv(bgr: Mat) {
        Imgproc.cvtColor(bgr, yuvMat, Imgproc.COLOR_BGR2YUV_I420)
        yuvMat.get(0, 0, i420)

        val planar = colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar ||
            colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible

        if (planar) {
            System.arraycopy(i420, 0, outBytes, 0, i420.size)
        } else {
            // I420 -> NV12：Y 直拷，UV 交织
            System.arraycopy(i420, 0, outBytes, 0, ySize)
            var src = ySize
            var dst = ySize
            for (i in 0 until uvSize) {
                outBytes[dst++] = i420[src + i]           // U
                outBytes[dst++] = i420[src + uvSize + i]  // V
            }
        }
    }

    private fun selectEncoder(): Pair<MediaCodecInfo, Int> {
        val candidates = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(MIME, true) } }

        val preference = intArrayOf(
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar,
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar,
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
        )

        for (info in candidates.sortedByDescending { isHardware(it) }) {
            val caps = try {
                info.getCapabilitiesForType(MIME)
            } catch (_: Throwable) {
                continue
            }
            for (fmt in preference) {
                if (caps.colorFormats.contains(fmt)) return info to fmt
            }
        }
        throw IllegalStateException(
            "没有可用的 H.264 编码器支持 YUV420 字节缓冲输入，请换设备或改用 Surface 输入方案"
        )
    }

    private fun isHardware(info: MediaCodecInfo): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            info.isHardwareAccelerated
        } else {
            !info.name.startsWith("OMX.google") && !info.name.startsWith("c2.android")
        }

    companion object {
        const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC
    }
}
