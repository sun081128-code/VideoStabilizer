package com.example.videostab.stabilizer

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteBuffer

/**
 * 音频直通：用 MediaExtractor 按原始编码帧读出，原样交给 MediaMuxer 写回，
 * 不解码也不重编码，音质和时长都不变。
 *
 * 用法是"被视频时间戳牵着走"：视频每写一帧，就让它把 PTS <= 该帧的音频包全吐出来，
 * 这样写进 MP4 的两个轨道天然交错，播放器 seek 也正常。
 */
class AudioPassthrough(sourcePath: String) {

    class Sample(val data: ByteArray, val ptsUs: Long, val flags: Int)

    val format: MediaFormat?
    val hasAudio: Boolean
    private val extractor = MediaExtractor()
    private var pending: Sample? = null
    private var eos = false
    private val scratch = ByteBuffer.allocateDirect(256 * 1024)

    init {
        extractor.setDataSource(sourcePath)
        var index = -1
        var trackFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                index = i
                trackFormat = f
                break
            }
        }
        if (index >= 0 && trackFormat != null) {
            extractor.selectTrack(index)
            format = trackFormat
            hasAudio = true
            pending = readNext()          // 先探一包，确认真的有数据
        } else {
            format = null
            hasAudio = false
        }
    }

    /** 吐出 PTS <= limitUs 的所有音频包 */
    fun pumpUntil(limitUs: Long, write: (Sample) -> Unit) {
        if (!hasAudio) return
        while (true) {
            val sample = pending ?: readNext() ?: run { pending = null; return }
            if (sample.ptsUs > limitUs) {
                pending = sample
                return
            }
            write(sample)
            pending = null
        }
    }

    /** 收尾：把剩下的全吐出去 */
    fun drainAll(write: (Sample) -> Unit) {
        if (!hasAudio) return
        while (true) {
            val sample = pending ?: readNext() ?: return
            write(sample)
            pending = null
        }
    }

    fun release() {
        try {
            extractor.release()
        } catch (_: Throwable) {
        }
    }

    private fun readNext(): Sample? {
        if (eos) return null
        scratch.clear()
        val size = extractor.readSampleData(scratch, 0)
        if (size <= 0) {
            eos = true
            return null
        }
        val bytes = ByteArray(size)
        scratch.position(0)
        scratch.get(bytes, 0, size)
        return Sample(
            data = bytes,
            ptsUs = extractor.sampleTime,
            flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else {
                0
            }
        )
    }
}
