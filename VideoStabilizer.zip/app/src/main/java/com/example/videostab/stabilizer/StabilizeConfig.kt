package com.example.videostab.stabilizer

/**
 * 防抖参数。默认值基本就是需求里写的那套。
 */
data class StabilizeConfig(
    /** 滑杆给的裁剪比例 0.05 ~ 0.15，是"下限"，实际裁剪可能更大（见 [maxCropLimit]） */
    val cropRatio: Float = 0.10f,
    /** 平滑窗口（帧），半径 = window / 2 */
    val smoothingWindow: Int = 30,
    /** 每帧最多保留的特征点 */
    val maxFeatures: Int = 200,
    /** 分析阶段缩到的高度；源视频不高于该值时不缩放 */
    val analysisHeight: Int = 720,
    /** 单帧平移补偿上限，相对画面宽/高的比例 */
    val maxTranslationRatio: Float = 0.05f,
    /** 单帧旋转补偿上限（度） */
    val maxRotationDeg: Float = 2.0f,
    /** 裁剪比例硬上限：极端抖动时也不允许超过这个值 */
    val maxCropLimit: Float = 0.35f,
    /** goodFeaturesToTrack 质量阈值 */
    val featureQuality: Double = 0.01,
    /** goodFeaturesToTrack 最小间距（分析分辨率下的像素） */
    val minFeatureDistance: Double = 10.0,
    /** LK 光流窗口边长 */
    val lkWindow: Int = 21,
    /** LK 金字塔层数 */
    val lkLevels: Int = 3,
    /** 少于这个内点数就认为该帧跟踪失败，按"无运动"处理 */
    val minTrackedPoints: Int = 8
)
