package com.example.videostab

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.videostab.databinding.ActivityMainBinding
import com.example.videostab.stabilizer.StabilizeConfig
import com.example.videostab.stabilizer.VideoStabilizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.opencv.android.OpenCVLoader
import java.io.File
import java.util.Locale

/**
 * 单页界面：选视频 -> 调强度 -> 跑防抖（后台线程 + 进度条）-> 原片/结果对比播放。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var sourceFile: File? = null
    private var resultFile: File? = null
    private var engine: VideoStabilizer? = null
    private var busy = false

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importVideo(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // OpenCV 4.8+ 用 initLocal()；更老的版本是 OpenCVLoader.initDebug()
        if (!OpenCVLoader.initLocal()) {
            toast("OpenCV 初始化失败，检查 so 是否打进 APK")
        }

        binding.sliderCrop.value = 10f
        updateCropLabel(10f)
        binding.sliderCrop.addOnChangeListener { _, value, _ -> updateCropLabel(value) }

        binding.btnPick.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        binding.btnStart.setOnClickListener { startStabilize() }
        binding.btnCancel.setOnClickListener {
            engine?.cancel()
            binding.tvStatus.text = "正在取消…"
        }
        binding.btnCompare.setOnClickListener { playBoth() }
        binding.btnStop.setOnClickListener { stopBoth() }

        updateUiState()
    }

    override fun onPause() {
        super.onPause()
        stopBoth()
    }

    override fun onDestroy() {
        engine?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ 选片 / 导入

    private fun importVideo(uri: Uri) {
        if (busy) return
        lifecycleScope.launch {
            setBusy(true, "正在导入视频…")
            val imported = withContext(Dispatchers.IO) {
                runCatching { copyToCache(uri) }
            }
            setBusy(false)
            imported.onSuccess { file ->
                sourceFile = file
                resultFile = null
                binding.tvSourceInfo.text = String.format(
                    Locale.US, "%s  ·  %.1f MB", file.name, file.length() / 1024.0 / 1024.0
                )
                binding.videoOriginal.setVideoPath(file.absolutePath)
                binding.videoOriginal.seekTo(1)
                binding.videoResult.stopPlayback()
                binding.progress.progress = 0
                binding.tvStatus.text = "已选择视频，点“开始防抖”"
                updateUiState()
            }.onFailure {
                toast("导入失败：${it.message}")
                binding.tvStatus.text = "导入失败"
            }
        }
    }

    /** OpenCV VideoCapture 只认文件路径，所以先把 content:// 拷到私有缓存 */
    private fun copyToCache(uri: Uri): File {
        val name = queryDisplayName(uri) ?: "source_${System.currentTimeMillis()}.mp4"
        val dir = File(cacheDir, "input").apply { mkdirs() }
        val target = File(dir, name)
        contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
        } ?: throw IllegalStateException("读不到所选文件")
        return target
    }

    private fun queryDisplayName(uri: Uri): String? {
        return contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }
    }

    // ------------------------------------------------------------ 处理

    private fun startStabilize() {
        val src = sourceFile ?: return
        if (busy) return

        val outDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        outDir.mkdirs()
        val out = File(outDir, "stabilized_${System.currentTimeMillis()}.mp4")

        val config = StabilizeConfig(
            cropRatio = binding.sliderCrop.value / 100f
        )

        val stabilizer = VideoStabilizer(config) { percent, message ->
            // 回调来自后台线程
            runOnUiThread {
                binding.progress.progress = percent
                binding.tvStatus.text = message
            }
        }
        engine = stabilizer

        setBusy(true, "准备中…")
        binding.progress.progress = 0
        binding.videoResult.stopPlayback()

        lifecycleScope.launch {
            val outcome = withContext(Dispatchers.Default) {
                runCatching { stabilizer.process(src.absolutePath, out.absolutePath) }
            }
            engine = null
            setBusy(false)

            outcome.onSuccess { result ->
                resultFile = File(result.outputPath)
                binding.progress.progress = 100
                binding.tvStatus.text = String.format(
                    Locale.US,
                    "完成 · %d×%d · 裁剪 %.1f%% · %d 帧 · 用时 %.1fs",
                    result.outputWidth,
                    result.outputHeight,
                    result.appliedCropRatio * 100,
                    result.frameCount,
                    result.elapsedMs / 1000.0
                )
                binding.videoResult.setVideoPath(result.outputPath)
                binding.videoResult.seekTo(1)
            }.onFailure { e ->
                out.delete()
                binding.tvStatus.text = "失败：${e.message}"
                toast("处理失败：${e.message}")
            }
            updateUiState()
        }
    }

    // ------------------------------------------------------------ 对比播放

    private fun playBoth() {
        if (sourceFile == null || resultFile == null) {
            toast("先处理一段视频")
            return
        }
        binding.videoOriginal.seekTo(0)
        binding.videoResult.seekTo(0)
        binding.videoOriginal.start()
        binding.videoResult.start()
    }

    private fun stopBoth() {
        runCatching { binding.videoOriginal.stopPlayback() }
        runCatching { binding.videoResult.stopPlayback() }
    }

    // ------------------------------------------------------------ UI 状态

    private fun updateCropLabel(value: Float) {
        binding.tvCropValue.text = String.format(Locale.US, "%.0f%%", value)
    }

    private fun setBusy(value: Boolean, message: String? = null) {
        busy = value
        if (message != null) binding.tvStatus.text = message
        binding.btnPick.isEnabled = !value
        binding.btnCancel.visibility = if (value) View.VISIBLE else View.GONE
        updateUiState()
    }

    private fun updateUiState() {
        binding.btnStart.isEnabled = !busy && sourceFile != null
        binding.sliderCrop.isEnabled = !busy
        binding.btnCompare.isEnabled = !busy && resultFile != null
        binding.btnStop.isEnabled = resultFile != null
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
