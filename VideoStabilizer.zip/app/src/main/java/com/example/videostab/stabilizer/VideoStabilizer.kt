package com.example.videostab.stabilizer

import android.media.MediaCodec
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.SystemClock
import android.util.Log
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.core.TermCriteria
import org.opencv.calib3d.Calib3d
import org.opencv.imgproc.Imgproc
import org.opencv.video.Video
import org.opencv.videoio.VideoCapture
import org.opencv.videoio.Videoio
import java.io.IOException
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 防抖核心。整条流水线：
 *
 *   Pass 1（分析）  解码 -> 缩到 720p -> 灰度 -> GFTT + LK -> estimateAffinePartial2D
 *                   -> 累积成相机轨迹 -> 滑动平均 -> 限幅 -> 算需要的最小裁剪
 *   Pass 2（渲染）  重新解码原分辨率帧 -> warpAffine(修正矩阵 + 裁剪平移) -> MediaCodec
 *                   -> MediaMuxer（视频轨新编码 + 音频轨原样拷贝）
 *
 * 用两遍而不是缓存所有帧，是因为 1080p 一帧 BGR 就 6MB，缓存几百帧直接 OOM；
 * 而 VideoCapture 重新打开一次的成本远小于内存爆掉。
 */
class VideoStabilizer(
    private val config: StabilizeConfig,
    private val onProgress: (percent: Int, message: String) -> Unit
) {
    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
    }

    data class Result(
        val outputPath: String,
        val frameCount: Int,
        val outputWidth: Int,
        val outputHeight: Int,
        /** 实际使用的裁剪比例（可能是滑杆值，也可能是限幅后需要的更大值） */
        val appliedCropRatio: Float,
        /** 全片最大单帧平移补偿（像素），用来核对限幅是否生效 */
        val maxShiftPx: Double,
        val elapsedMs: Long
    )

    fun process(sourcePath: String, outputPath: String): Result {
        val startedAt = SystemClock.elapsedRealtime()
        val plan = analyze(sourcePath)
        checkCancelled()
        encode(sourcePath, outputPath, plan)

        return Result(
            outputPath = outputPath,
            frameCount = plan.frameCount,
            outputWidth = plan.outW,
            outputHeight = plan.outH,
            appliedCropRatio = plan.cropRatio,
            maxShiftPx = plan.maxShiftPx,
            elapsedMs = SystemClock.elapsedRealtime() - startedAt
        )
    }

    // =================================================================== Pass 1

    private class Plan(
        val frameCount: Int,
        val fps: Double,
        val srcW: Int,
        val srcH: Int,
        val corrections: List<SimTransform>,
        val cropRatio: Float,
        val outW: Int,
        val outH: Int,
        val viewX: Int,
        val viewY: Int,
        val maxShiftPx: Double
    )

    private fun analyze(sourcePath: String): Plan {
        report(0, "分析画面抖动…")
        val cap = VideoCapture(sourcePath)
        if (!cap.isOpened()) throw IOException("打不开视频：$sourcePath")

        val srcW = cap.get(Videoio.CAP_PROP_FRAME_WIDTH).roundToInt()
        val srcH = cap.get(Videoio.CAP_PROP_FRAME_HEIGHT).roundToInt()
        if (srcW <= 0 || srcH <= 0) {
            cap.release()
            throw IOException("读不到视频尺寸")
        }

        var fps = cap.get(Videoio.CAP_PROP_FPS)
        if (!fps.isFinite() || fps < 1.0 || fps > 240.0) fps = 30.0
        val estimated = cap.get(Videoio.CAP_PROP_FRAME_COUNT).roundToInt()

        // 分析分辨率：高度压到 720p，宽高取偶数（YUV/GRAY 转换要求）
        val scale = if (srcH > config.analysisHeight) {
            config.analysisHeight.toDouble() / srcH
        } else {
            1.0
        }
        val aw = (((srcW * scale).roundToInt()) / 2 * 2).coerceAtLeast(2)
        val ah = (((srcH * scale).roundToInt()) / 2 * 2).coerceAtLeast(2)
        // 取整会带来一点误差，平移要用真实比例换算回原分辨率
        val sx = aw.toDouble() / srcW
        val sy = ah.toDouble() / srcH
        val small = Size(aw.toDouble(), ah.toDouble())

        var frameCount = 0
        val transforms = ArrayList<SimTransform>()

        val frame = Mat()
        val smallFrame = Mat()
        val gray = Mat()
        val prevGray = Mat()
        try {
            var hasPrev = false
            var index = 0
            var lastPct = -1

            while (!cancelled && cap.read(frame)) {
                if (frame.empty()) break
                frameCount = index + 1

                if (scale < 1.0) {
                    Imgproc.resize(frame, smallFrame, small, 0.0, 0.0, Imgproc.INTER_AREA)
                } else {
                    frame.copyTo(smallFrame)
                }
                Imgproc.cvtColor(smallFrame, gray, Imgproc.COLOR_BGR2GRAY)

                if (hasPrev) {
                    val t = estimateFrameMotion(prevGray, gray, sx, sy)
                    transforms.add(t ?: SimTransform.IDENTITY)
                }
                gray.copyTo(prevGray)
                hasPrev = true
                index++

                if (index % 2 == 0) {
                    val pct = if (estimated > 0) {
                        (45.0 * index / estimated).roundToInt().coerceIn(0, 45)
                    } else {
                        0
                    }
                    if (pct != lastPct) {
                        lastPct = pct
                        report(pct, "分析画面抖动… 第 $index 帧")
                    }
                }
            }
        } finally {
            frame.release()
            smallFrame.release()
            gray.release()
            prevGray.release()
            cap.release()
        }

        if (cancelled) throw CancellationException()
        if (frameCount < 5) throw IllegalStateException("视频太短，至少需要 5 帧")

        // 补齐：跟踪失败或帧数不齐时按静止处理
        while (transforms.size < frameCount - 1) transforms.add(SimTransform.IDENTITY)

        val corrections = buildCorrections(transforms, frameCount)
        return makePlan(srcW, srcH, fps, frameCount, corrections)
    }

    /**
     * 在分析分辨率上算帧间运动，再把平移换算回原分辨率尺度。
     * 旋转/缩放不受分辨率影响，只换算 tx/ty。
     */
    private fun estimateFrameMotion(
        prevGray: Mat,
        gray: Mat,
        scaleX: Double,
        scaleY: Double
    ): SimTransform? {
        // 注意：goodFeaturesToTrack 的 Java 绑定输出类型是 MatOfPoint（整点），
        // 而 calcOpticalFlowPyrLK 要 MatOfPoint2f（浮点），中间必须转一次
        val corners = MatOfPoint()
        Imgproc.goodFeaturesToTrack(
            prevGray, corners, config.maxFeatures,
            config.featureQuality, config.minFeatureDistance,
            Mat(), 3, false, 0.04
        )
        if (corners.empty() || corners.rows() < config.minTrackedPoints) {
            corners.release()
            return null
        }

        val prevPts = MatOfPoint2f(*corners.toArray())
        corners.release()

        val nextPts = MatOfPoint2f()
        val status = MatOfByte()
        val err = MatOfFloat()
        val criteria = TermCriteria(
            TermCriteria.COUNT or TermCriteria.EPS, 30, 0.01
        )

        try {
            Video.calcOpticalFlowPyrLK(
                prevGray, gray, prevPts, nextPts, status, err,
                Size(config.lkWindow.toDouble(), config.lkWindow.toDouble()),
                config.lkLevels, criteria, 0, 0.001
            )

            val st = status.toArray()
            val p0 = prevPts.toArray()
            val p1 = nextPts.toArray()
            if (p0.size != st.size || p0.size != p1.size) return null

            val good0 = ArrayList<Point>(p0.size)
            val good1 = ArrayList<Point>(p0.size)
            val maxX = (prevGray.cols() - 1).toDouble()
            val maxY = (prevGray.rows() - 1).toDouble()

            for (i in p0.indices) {
                if (st[i].toInt() != 1) continue
                val a = p0[i]
                val b = p1[i]
                // 丢掉跑出画面的点，它们的光流不可信
                if (!b.x.isFinite() || !b.y.isFinite()) continue
                if (b.x < 0.0 || b.y < 0.0 || b.x > maxX || b.y > maxY) continue
                good0.add(a)
                good1.add(b)
            }

            if (good0.size < config.minTrackedPoints) return null

            val from = MatOfPoint2f(*good0.toTypedArray())
            val to = MatOfPoint2f(*good1.toTypedArray())
            val inliers = Mat()
            val m = Calib3d.estimateAffinePartial2D(
                from, to, inliers, Calib3d.RANSAC, 3.0
            )

            val inlierCount = if (inliers.empty()) 0 else Core.countNonZero(inliers)
            val t = SimTransform.fromMat(m)

            from.release()
            to.release()
            inliers.release()
            m?.release()

            if (t == null || inlierCount < config.minTrackedPoints) return null

            // 平移换算回原分辨率，旋转/缩放不变
            return SimTransform(t.a, t.b, t.tx / scaleX, t.ty / scaleY)
        } finally {
            prevPts.release()
            nextPts.release()
            status.release()
            err.release()
        }
    }

    /**
     * 累积轨迹 -> 平滑 -> 求每帧修正矩阵 -> 限幅
     */
    private fun buildCorrections(
        transforms: List<SimTransform>,
        frameCount: Int
    ): List<SimTransform> {
        // 1) 累积：path[i] 表示"第 0 帧的点在第 i 帧的位置"
        val path = ArrayList<SimTransform>(frameCount)
        var cum = SimTransform.IDENTITY
        path.add(cum)
        for (t in transforms) {
            cum = t.compose(cum)
            path.add(cum)
        }

        // 2) 拆成 角度/平移 三条一维序列分别平滑；缩放不参与（否则会呼吸式缩放）
        val n = path.size
        val angles = DoubleArray(n) { path[it].angleRad }
        val txs = DoubleArray(n) { path[it].tx }
        val tys = DoubleArray(n) { path[it].ty }

        val smoothAngles = MotionSmoother.movingAverage(
            MotionSmoother.unwrapRadians(angles), config.smoothingWindow
        )
        val smoothTx = MotionSmoother.movingAverage(txs, config.smoothingWindow)
        val smoothTy = MotionSmoother.movingAverage(tys, config.smoothingWindow)

        // 3) 修正 = 平滑轨迹 ∘ 原始轨迹的逆；角度在这里限幅，平移留到 makePlan 按像素限幅
        val maxAngle = Math.toRadians(config.maxRotationDeg.toDouble())
        val corrections = ArrayList<SimTransform>(n)
        for (i in 0 until n) {
            val smooth = SimTransform.of(smoothAngles[i], smoothTx[i], smoothTy[i])
            val c = smooth.compose(path[i].inverse())

            val angle = c.angleRad.coerceIn(-maxAngle, maxAngle)
            corrections.add(SimTransform.of(angle, c.tx, c.ty))
        }
        Log.d(TAG, "轨迹 $n 帧，平滑窗口 ${config.smoothingWindow}，角度限幅 ±${config.maxRotationDeg}°")
        return corrections
    }

    private fun makePlan(
        srcW: Int,
        srcH: Int,
        fps: Double,
        frameCount: Int,
        rawCorrections: List<SimTransform>
    ): Plan {
        // 4) 平移限幅（按像素）
        val maxShiftX = srcW * config.maxTranslationRatio
        val maxShiftY = srcH * config.maxTranslationRatio
        var maxShift = 0.0
        val corrections = rawCorrections.map { c ->
            val tx = c.tx.coerceIn(-maxShiftX.toDouble(), maxShiftX.toDouble())
            val ty = c.ty.coerceIn(-maxShiftY.toDouble(), maxShiftY.toDouble())
            maxShift = maxOf(maxShift, abs(tx), abs(ty))
            SimTransform.of(c.angleRad, tx, ty)
        }

        // 5) 限幅之后仍有位移，用裁剪把露出来的黑边吃进去：
        //    求"所有帧都装得下"的最小裁剪比例，再和滑杆值取大
        val need = requiredCrop(corrections, srcW, srcH)
        val crop = (maxOf(config.cropRatio.toDouble(), need + 0.004))
            .coerceAtMost(config.maxCropLimit.toDouble())

        // 6) 输出尺寸：向下取到 16 的整数倍（编码器对 YUV 宽高对齐有要求）
        val outW = ((srcW * (1.0 - crop)).toInt() / 16 * 16).coerceIn(16, srcW)
        val outH = ((srcH * (1.0 - crop)).toInt() / 16 * 16).coerceIn(16, srcH)
        val viewX = (srcW - outW) / 2
        val viewY = (srcH - outH) / 2

        Log.d(TAG, "src=${srcW}x$srcH needCrop=${"%.3f".format(need)} crop=${"%.3f".format(crop)} out=${outW}x$outH")

        return Plan(
            frameCount = frameCount,
            fps = fps,
            srcW = srcW,
            srcH = srcH,
            corrections = corrections,
            cropRatio = crop.toFloat(),
            outW = outW,
            outH = outH,
            viewX = viewX,
            viewY = viewY,
            maxShiftPx = maxShift
        )
    }

    /**
     * 求一个裁剪比例 s，使得每一帧经过修正后，居中的 (w(1-s), h(1-s)) 区域
     * 反变换回去仍然完整落在原图内。s 越大越容易满足，单调，可以二分。
     */
    private fun requiredCrop(corrections: List<SimTransform>, w: Int, h: Int): Double {
        var worst = 0.0
        for (c in corrections) {
            if (c.tx == 0.0 && c.ty == 0.0 && c.a == 1.0 && c.b == 0.0) continue
            val inv = c.inverse()
            if (fitsInside(inv, w, h, worst)) continue   // 当前最差值就够了
            if (!fitsInside(inv, w, h, 0.6)) {
                worst = 0.6
                continue
            }
            var lo = worst
            var hi = 0.6
            repeat(20) {
                val mid = (lo + hi) / 2
                if (fitsInside(inv, w, h, mid)) hi = mid else lo = mid
            }
            if (hi > worst) worst = hi
        }
        return worst
    }

    private fun fitsInside(inv: SimTransform, w: Int, h: Int, crop: Double): Boolean {
        val halfW = w * (1.0 - crop) / 2.0
        val halfH = h * (1.0 - crop) / 2.0
        val cx = w / 2.0
        val cy = h / 2.0
        val xs = doubleArrayOf(cx - halfW, cx + halfW, cx - halfW, cx + halfW)
        val ys = doubleArrayOf(cy - halfH, cy - halfH, cy + halfH, cy + halfH)
        for (k in 0 until 4) {
            val x = inv.a * xs[k] - inv.b * ys[k] + inv.tx
            val y = inv.b * xs[k] + inv.a * ys[k] + inv.ty
            if (x < -0.5 || y < -0.5 || x > w - 0.5 || y > h - 0.5) return false
        }
        return true
    }

    // =================================================================== Pass 2

    private fun encode(sourcePath: String, outputPath: String, plan: Plan) {
        val cap = VideoCapture(sourcePath)
        if (!cap.isOpened()) throw IOException("第二遍解码打不开视频")

        val frameRate = plan.fps.roundToInt().coerceIn(15, 60)
        val bitRate = sourceBitrate(sourcePath).takeIf { it > 0 }
            ?: (plan.outW * plan.outH * frameRate * 0.15).toInt()

        val encoder = H264Encoder(plan.outW, plan.outH, frameRate, bitRate)
        val audio = AudioPassthrough(sourcePath)
        val muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        var muxerStarted = false
        var videoTrack = -1
        var audioTrack = -1
        var videoFormat: android.media.MediaFormat? = null

        fun startMuxerIfNeeded() {
            if (muxerStarted) return
            val vf = videoFormat ?: return
            videoTrack = muxer.addTrack(vf)
            audioTrack = if (audio.hasAudio && audio.format != null) {
                muxer.addTrack(audio.format!!)
            } else {
                -1
            }
            muxer.start()
            muxerStarted = true
        }

        fun writeAudio(sample: AudioPassthrough.Sample) {
            if (!muxerStarted || audioTrack < 0) return
            val info = MediaCodec.BufferInfo().apply {
                set(0, sample.data.size, sample.ptsUs, sample.flags)
            }
            muxer.writeSampleData(audioTrack, ByteBuffer.wrap(sample.data), info)
        }

        encoder.onOutputFormat = { fmt ->
            videoFormat = fmt
            startMuxerIfNeeded()
        }
        encoder.onSample = { buffer, info ->
            if (muxerStarted && videoTrack >= 0 && info.size > 0) {
                muxer.writeSampleData(videoTrack, buffer, info)
                // 关键：音频跟着视频时间戳走，保证两条轨道交错写入
                if (audioTrack >= 0) audio.pumpUntil(info.presentationTimeUs) { writeAudio(it) }
            }
        }

        val frame = Mat()
        val warped = Mat()
        val dsSize = Size(plan.outW.toDouble(), plan.outH.toDouble())
        // 把裁剪窗口左上角挪到原点：先做修正，再整体平移 -viewX/-viewY
        val cropShift = SimTransform.translation(-plan.viewX.toDouble(), -plan.viewY.toDouble())

        try {
            encoder.start()
            var index = 0
            while (!cancelled && cap.read(frame)) {
                if (frame.empty()) break

                val fix = plan.corrections.getOrElse(index) { SimTransform.IDENTITY }
                val matrix = cropShift.compose(fix).toMat()

                Imgproc.warpAffine(
                    frame, warped, matrix, dsSize,
                    Imgproc.INTER_LINEAR,
                    Core.BORDER_REPLICATE,   // 理论上不会触发（裁剪已保证覆盖），兜底而已
                    Scalar(0.0, 0.0, 0.0)
                )
                matrix.release()

                val ptsUs = (index * 1_000_000.0 / plan.fps).toLong()
                encoder.queueFrame(warped, ptsUs)

                index++
                val pct = 45 + (55.0 * index / plan.frameCount).roundToInt().coerceIn(0, 55)
                report(pct, "渲染并编码… $index/${plan.frameCount}")
            }

            if (cancelled) throw CancellationException()

            encoder.finish()
            audio.drainAll { writeAudio(it) }

            if (muxerStarted) muxer.stop()
        } finally {
            try {
                muxer.release()
            } catch (_: Throwable) {
            }
            encoder.release()
            audio.release()
            frame.release()
            warped.release()
            cap.release()
        }
    }

    private fun sourceBitrate(path: String): Int = try {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(path)
        val value = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            ?.toIntOrNull() ?: 0
        mmr.release()
        value
    } catch (_: Throwable) {
        0
    }

    // =================================================================== util

    private fun report(percent: Int, message: String) {
        onProgress(percent, message)
    }

    private fun checkCancelled() {
        if (cancelled) throw CancellationException()
    }

    class CancellationException : RuntimeException("已取消")

    companion object {
        private const val TAG = "VideoStabilizer"
    }
}
