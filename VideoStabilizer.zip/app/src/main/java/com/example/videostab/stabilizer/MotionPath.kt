package com.example.videostab.stabilizer

import org.opencv.core.CvType
import org.opencv.core.Mat
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * 相似变换（旋转 + 等比缩放 + 平移），和 estimateAffinePartial2D 的输出同构：
 *
 *     | a  -b  tx |
 *     | b   a  ty |
 *
 * 用 4 个自由度表示一帧相机运动，比 6 自由度全仿射更稳（不会出现剪切变形）。
 */
data class SimTransform(
    val a: Double = 1.0,
    val b: Double = 0.0,
    val tx: Double = 0.0,
    val ty: Double = 0.0
) {
    val angleRad: Double get() = atan2(b, a)
    val angleDeg: Double get() = Math.toDegrees(angleRad)
    val scale: Double get() = hypot(a, b)

    /** this ∘ other：先做 other 再做 this，等价于矩阵相乘 M(this) * M(other) */
    fun compose(other: SimTransform): SimTransform = SimTransform(
        a = a * other.a - b * other.b,
        b = a * other.b + b * other.a,
        tx = a * other.tx - b * other.ty + tx,
        ty = b * other.tx + a * other.ty + ty
    )

    fun inverse(): SimTransform {
        val s2 = a * a + b * b
        if (s2 < 1e-12) return IDENTITY
        return SimTransform(
            a = a / s2,
            b = -b / s2,
            tx = -(a * tx + b * ty) / s2,
            ty = (b * tx - a * ty) / s2
        )
    }

    /** 2x3 CV_64F，直接喂给 warpAffine */
    fun toMat(): Mat {
        val m = Mat(2, 3, CvType.CV_64F)
        m.put(0, 0, a, -b, tx)
        m.put(1, 0, b, a, ty)
        return m
    }

    companion object {
        val IDENTITY = SimTransform()

        fun of(angleRad: Double, tx: Double, ty: Double) =
            SimTransform(cos(angleRad), sin(angleRad), tx, ty)

        fun translation(dx: Double, dy: Double) = SimTransform(1.0, 0.0, dx, dy)

        /** 从 estimateAffinePartial2D 返回的 2x3 矩阵读出参数 */
        fun fromMat(m: Mat?): SimTransform? {
            if (m == null || m.empty() || m.rows() != 2 || m.cols() != 3) return null
            val d = DoubleArray(6)
            m.get(0, 0, d)
            if (d.any { !it.isFinite() }) return null
            // d = [a, -b, tx, b, a, ty]
            return SimTransform(a = d[0], b = d[3], tx = d[2], ty = d[5])
        }
    }
}

/**
 * 一维轨迹平滑工具。
 */
object MotionSmoother {

    /**
     * 滑动平均。window = 30 帧即半径 15，首尾自动收缩窗口，不做零填充，
     * 保证起止帧不被拉向 0 而出现开头/结尾的"回弹"。
     */
    fun movingAverage(values: DoubleArray, window: Int): DoubleArray {
        if (values.isEmpty()) return values
        val n = values.size
        val r = (window / 2).coerceAtLeast(1)
        // 前缀和，O(n) 完成整段平滑
        val prefix = DoubleArray(n + 1)
        for (i in 0 until n) prefix[i + 1] = prefix[i] + values[i]
        val out = DoubleArray(n)
        for (i in 0 until n) {
            val lo = (i - r).coerceAtLeast(0)
            val hi = (i + r).coerceAtMost(n - 1)
            out[i] = (prefix[hi + 1] - prefix[lo]) / (hi - lo + 1)
        }
        return out
    }

    /** 角度累积后要解卷绕，否则 ±π 处会跳变把平滑窗口撕开 */
    fun unwrapRadians(angles: DoubleArray): DoubleArray {
        val out = angles.copyOf()
        var offset = 0.0
        val twoPi = Math.PI * 2
        for (i in 1 until out.size) {
            var d = angles[i] + offset - out[i - 1]
            while (d > Math.PI) {
                offset -= twoPi
                d -= twoPi
            }
            while (d < -Math.PI) {
                offset += twoPi
                d += twoPi
            }
            out[i] = angles[i] + offset
        }
        return out
    }
}
