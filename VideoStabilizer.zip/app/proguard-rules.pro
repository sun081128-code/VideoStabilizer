# OpenCV 的 Java 类通过 JNI 与 so 里的符号按"全限定类名 + 方法名"绑定，
# 一旦开启 minifyEnabled 把类名混淆掉，就会 UnsatisfiedLinkError。
# 所以只要开混淆，这几条必须保留。
-keep class org.opencv.** { *; }
-keepclassmembers class org.opencv.** {
    native <methods>;
    public static <methods>;
}
-dontwarn org.opencv.**
