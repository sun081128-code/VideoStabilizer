# 视频防抖 App（OpenCV VideoCapture + MediaCodec/MediaMuxer）

选一段本地视频 → 做防抖 → 存成新 mp4，保留原音频，尽量保留原分辨率。

技术路线固定为你给的那套：**GFTT + LK 光流 + estimateAffinePartial2D 累积轨迹 + 滑动平均（30 帧）+ warpAffine**，没有引入深度学习。

---

## 1. 工程结构

```
VideoStabilizer/
├── settings.gradle.kts
├── build.gradle.kts                  # 根：AGP 8.1.4 / Kotlin 1.9.22
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts              # compileSdk 33 / minSdk 24 / OpenCV Maven 依赖
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/videostab/
        │   ├── MainActivity.kt               # 选片 / 滑杆 / 进度 / 对比播放
        │   └── stabilizer/
        │       ├── StabilizeConfig.kt        # 全部可调参数（窗口、限幅、720p…）
        │       ├── MotionPath.kt             # SimTransform（相似变换）+ 滑动平均/解卷绕
        │       ├── VideoStabilizer.kt        # 核心：分析轨迹 → 平滑 → 限幅 → 算裁剪 → 渲染
        │       ├── H264Encoder.kt            # MediaCodec 封装 + BGR→YUV420
        │       └── AudioPassthrough.kt       # MediaExtractor 音频轨原样复制
        └── res/
            ├── layout/activity_main.xml
            └── values/{strings,colors,themes}.xml
```

文件职责一句话版：

| 文件 | 干什么 |
|---|---|
| `VideoStabilizer.kt` | 两遍流水线：Pass1 只算变换（720p），Pass2 用原分辨率帧做 warp + 编码 |
| `MotionPath.kt` | 用 `(a,b,tx,ty)` 表示相似变换，提供 compose / inverse / toMat，以及 O(n) 滑动平均 |
| `H264Encoder.kt` | byte-buffer 输入编码，自动在 Planar / SemiPlanar / Flexible 之间挑格式 |
| `AudioPassthrough.kt` | 音频包不解码，按视频时间戳"牵着走"写进 muxer |

---

## 2. 关键实现点

**为什么要两遍？** 滑动平均要看到整条轨迹才能算，但 1080p 一帧 BGR 就 6MB，缓存 300 帧 = 1.8GB，必 OOM。所以 Pass1 只读 720p 灰度算轨迹，Pass2 重新打开 `VideoCapture` 读原分辨率帧做 warp。

**轨迹怎么算：** `estimateAffinePartial2D(prevPts, nextPts)` 得到的是"第 i 帧坐标 → 第 i+1 帧坐标"的相似变换，累积 `cum = t ∘ cum` 得到相机路径。分辨率换算只影响平移（`tx /= scale`），旋转和缩放不受影响。

**修正矩阵：** `C_i = S_i ∘ cum_i⁻¹`（S 是平滑后的轨迹）。因为两者都是相似变换，这个式子是精确的，不是近似。

**边缘为什么不糊：** 每帧算出 `C_i` 后，先做单帧限幅（平移 ≤ 画面 5%，旋转 ≤ 2°），再用二分法求"所有帧都能装下"的最小裁剪比例 `need`，最后取 `crop = max(滑杆值, need)`。裁剪窗口固定居中、全片同一尺寸，所以不会出现逐帧缩放（zoom breathing），也不会把边缘像素拉伸出来——`warpAffine` 直接把裁剪窗口映射到输出画布，只做一次重采样。

**输出尺寸：** `outW/outH` 向下取到 16 的整数倍（编码器 YUV 对齐要求），所以 1920×1080 裁 10% 后是 1728×960，不是 1728×972。

**音频：** `MediaExtractor` 只读音频轨，`MediaMuxer` 用原 `MediaFormat` 加轨，码流逐包照抄。视频每写一帧，就把 PTS ≤ 该帧时间的音频包全吐出来，两条轨道天然交错。

---

## 3. 构建与打包

### 3.1 先让工程能同步

1. Android Studio（Giraffe 及以上）→ `File > Open` 选择 `VideoStabilizer` 目录。
2. 首次打开会生成 `local.properties`，确认里面有 `sdk.dir=/你的/Android/sdk`；没有就手写一行。
3. 工程自带 `gradlew` / `gradlew.bat` / `gradle-wrapper.jar`（Gradle 8.2），不用再生成 wrapper。
4. `org.opencv:opencv-android:4.10.0` 拉不下来时，按 `app/build.gradle.kts` 底部注释走手动导入：把 `opencv-4.10.0-android-sdk.zip` 里的 `sdk` 目录拷成工程根目录的 `opencv/`，`settings.gradle.kts` 加 `include(":opencv")`，依赖换成 `implementation(project(":opencv"))`。

> ABI 只保留了 `arm64-v8a` / `armeabi-v7a`。用模拟器测的话请选 arm64 镜像，x86_64 的 OpenCV so 需要自己编译。

### 3.2 debug 包（自己装上试）

Android Studio：`Build > Build Bundle(s) / APK(s) > Build APK(s)`，右下角弹窗点 `locate` 直接定位文件。

命令行：

```bash
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

产物：`app/build/outputs/apk/debug/app-debug.apk`

### 3.3 release 包（要签名才能装到别人手机上）

**第一步，生成 keystore（只做一次，丢了就永远无法覆盖升级）：**

```bash
keytool -genkeypair -v -keystore release.jks -alias videostab \
        -keyalg RSA -keysize 2048 -validity 36500
```

把 `release.jks` 放到**工程根目录**（和 `settings.gradle.kts` 同级）。

**第二步，工程根目录新建 `keystore.properties`：**

```properties
storeFile=release.jks
storePassword=你刚才输的密码
keyAlias=videostab
keyPassword=你刚才输的密码
```

`app/build.gradle.kts` 会自动读取它并给 release 配置签名；文件不存在时 release 包就是未签名的（`app-release-unsigned.apk`），不影响 debug 打包。`.gitignore` 已经把 `keystore.properties` 和 `*.jks` 排除掉了，别把它们提交上去。

**第三步，打包：**

```bash
./gradlew assembleRelease
```

产物：`app/build/outputs/apk/release/app-release.apk`

**第四步，验证签名和内容：**

```bash
# 看签名证书
$ANDROID_HOME/build-tools/33.0.2/apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk

# 确认两套 OpenCV so 都打进去了
unzip -l app/build/outputs/apk/release/app-release.apk | grep libopencv
#   lib/arm64-v8a/libopencv_java4.so
#   lib/armeabi-v7a/libopencv_java4.so
```

图形界面等价操作：`Build > Generate Signed Bundle / APK` → 选 **APK** → 选 keystore、填别名密码 → 选 `release` → Finish。

### 3.4 体积：按架构拆包

现在默认出的是 universal 包，两套 so 都在里面（OpenCV 的 so 单体就有 20MB+）。真机发布建议二选一：

- 打开 `app/build.gradle.kts` 里注释掉的 `splits { abi { ... } }` 段，`./gradlew assembleRelease` 会产出 `app-arm64-v8a-release.apk` 和 `app-armeabi-v7a-release.apk`，每个体积减半。
- 或者干脆只留 `arm64-v8a`：`abiFilters.clear(); abiFilters += "arm64-v8a"`（覆盖率已足够，armeabi-v7a 是 32 位老机器）。

想进一步瘦身还可以开 `isMinifyEnabled = true`，但**必须保留 `proguard-rules.pro` 里的 OpenCV keep 规则**，否则 JNI 符号绑不上，一启动就 `UnsatisfiedLinkError`。

### 3.5 打包报错对照表

| 现象 | 原因 | 处理 |
|---|---|---|
| `Could not find org.opencv:opencv-android:4.10.0` | 该坐标在你网络下不可达 / 版本没发布 | 走 3.1 第 4 步的手动导入 |
| `Plugin [id: 'com.android.application', version: '8.1.4'] was not found` | 无法访问 google() 仓库 | 配国内镜像，或换个能出网的网络 |
| `SDK location not found` | 缺 `local.properties` | 补 `sdk.dir=` |
| `UnsatisfiedLinkError: dlopen failed: library "libopencv_java4.so" not found` | so 没进 APK（ABI 被过滤掉了） | 检查 `abiFilters` 是否包含手机架构；解压 APK 看 `lib/` 目录 |
| 装机时 `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | 手机里已有同包名但不同签名的版本 | 先 `adb uninstall com.example.videostab` |
| release 包装上后一启动就崩，debug 没事 | 开了混淆但没 keep OpenCV | 见 3.4 末尾 |
| `Execution failed for task ':app:mergeReleaseNativeLibs'` | 手动导入的 opencv 模块里 so 重复 | 删掉 `opencv/src/main/jniLibs` 之外重复的一份，或设 `packaging { jniLibs.pickFirsts += "**/libopencv_java4.so" }` |


---

## 4. 测试步骤

### 4.1 准备素材

- 一段**有明显手抖**的短视频（10~20 秒足够），最好是 1080p、有声音，比如手持走路拍的街景。
- 再准备一段**基本不动**的（三脚架），用来验证"不该动的地方不会被乱动"。

### 4.2 跑通主流程

1. 装 APK，首次启动检查 Logcat 没有 `OpenCV 初始化失败`。
2. 点「选择视频」，用系统文件选择器挑视频 → 顶部显示文件名和大小，下方「原始视频」自动出现首帧。
3. 滑杆拉到 **10%**，点「开始防抖」。
4. 观察进度条：0→45% 是"分析画面抖动"，45%→100% 是"渲染并编码"。整段耗时大约是视频时长的 2~4 倍（中端机）。
5. 完成后状态栏显示 `完成 · 1728×960 · 裁剪 10.0% · N 帧 · 用时 xx.xs`，结果视频自动加载。
6. 点「对比播放」，两个 VideoView 同时从头播。

### 4.3 验证抖动是否真的被压下去

肉眼之外，建议这样量化（任选其一）：

- **看固定物体的位移**：找画面里一个远处静止目标（路灯、窗框），暂停在 t=0 和 t=5s，对比它在画面中的位置。防抖后应该基本不动；处理前会明显左右上下漂。
- **看边缘**：把结果视频逐帧拖一遍，重点看四条边——出现黑边、模糊、拉伸、或者画面"呼吸式"缩放都算失败。正常情况下边缘应该是清晰的原图内容，只是视野比原片窄一圈。
- **看音频**：用系统播放器确认有声音，且音画同步（口型/关门声对得上）。再对比时长：结果应与原片一致（误差 < 1 帧）。

### 4.4 验证限幅与裁剪逻辑

- 把滑杆拉到 **5%**：裁剪变少、视野更宽，但极端晃动的帧可能补偿不够（画面仍有轻微抖动）。
- 把滑杆拉到 **15%**：更稳，但视野明显变窄。
- 如果原片抖得特别厉害，真实裁剪会自动大于滑杆值（状态栏里的百分比会大于你选的值）——这就是"超出部分多裁剪"。
- 用 Logcat 过滤 `VideoStabilizer`，能看到 `src=1920x1080 needCrop=0.0xx crop=0.100 out=1728x960`，其中 `needCrop` 就是限幅后实际需要的裁剪量。

### 4.5 边界情况

| 场景 | 期望 |
|---|---|
| 竖屏视频（1080×1920） | 输出仍是竖屏，不旋转、不拉伸 |
| 无音轨的视频 | 正常出片，只是没有声音（音频轨不会加） |
| 视频里有快速摇镜/场景切换 | 该段画面会有轻微"卡顿感"，但不会出现黑边（跟踪失败按静止处理） |
| 处理中按「取消」 | 立即停在当前帧，输出文件被删除 |
| 处理中切后台 | 任务继续跑（前台 Activity 不销毁），回来仍是完成态 |

---

## 5. 已知限制

1. **只处理平移+旋转**（4 自由度），不做卷帘快门校正和 3D 稳定，快速旋转镜头会残留果冻效应。
2. **编码走 byte-buffer 输入**。极少数只支持 Surface 输入的硬件编码器会走不通，此时会自动退到软件编码器（`c2.android.avc.encoder`），速度慢一些但能出片。
3. **色彩异常**（红蓝互换）说明该机型的 `COLOR_FormatYUV420SemiPlanar` 实际是 NV21，把 `H264Encoder.fillYuv()` 里两个 `outBytes[dst++]` 的顺序对调即可。
4. 输出尺寸取 16 的整数倍，宽或高可能比"理论裁剪值"少几个像素。
5. 处理期间手机发热明显，长视频建议插电。

---

## 6. 没有电脑，只有手机，怎么把这堆代码变成 APK

先说结论：**AIDE 那类老式"手机打包 App"打不了这个工程**——它们只认 Groovy 版 `build.gradle` + Java 源码 + AGP 3.x/4.x，而本工程是 Kotlin 1.9 + AGP 8.1 + `build.gradle.kts` + viewBinding。要在手机上出包，用下面三条之一。

### 路径 A：AndroidIDE（本地编译，最贴近"复制到目录用软件打包"）

[AndroidIDE](https://androidide.com) 是一个开源的安卓端 IDE，自带 JDK 17 和 Android SDK，支持 Kotlin、Gradle Kotlin DSL 和 AGP 8.x，能在手机上真编译。

1. 装 AndroidIDE（官网 / F-Droid / GitHub Releases，注意要 arm64 手机、Android 8 以上、留 3GB 空间）。
2. 首次启动它会自动下载 JDK 17 + Android SDK，等它装完（要几分钟，别锁屏）。
3. 把 `VideoStabilizer.zip` 解压到手机任意目录（推荐 `内部存储/AndroidIDEProjects/VideoStabilizer/`）。
4. App 里 `Open Project` → 选刚才那个 `VideoStabilizer` 文件夹 → 等索引完成。
5. 点右上角 **Build**（或底部的 Run 图标）→ 产物在 `app/build/outputs/apk/debug/app-debug.apk`。
6. 在 App 内长按 APK 可以直接安装。

第一次 Build 要下 AGP、Kotlin、OpenCV 等依赖（几百 MB），全程手机流量，建议连 WiFi 并 `termux-wake-lock` 式地保持前台。

### 路径 B：GitHub Actions 云端编译（手机浏览器操作，不占手机性能）

工程里已经放好 `.github/workflows/build-apk.yml`，推上去就会自动编译。

1. 手机浏览器打开 github.com，注册/登录。
2. 右上角 `+` → `New repository`，建个空仓库（如 `videostab`）。
3. 把工程传上去。手机网页版上传嵌套文件夹很别扭，推荐用 **GitHub App** 或网页版切"桌面版网站"后 `Add file > Upload files` 拖整个文件夹；也可以本地用 Termux 的 git 推。
4. 进仓库顶部 **Actions** 标签 → 左侧 `Build APK` → 等 3~6 分钟变绿。
5. 点进这次运行 → 页面底部 **Artifacts** → 下载 `app-debug.zip` → 解压得到 `app-debug.apk`。
6. 允许"安装未知来源应用"后安装。

失败时在日志里搜 `Could not find org.opencv`——那是 Maven 坐标没解析到，按 3.1 第 4 步换成手动导入 OpenCV SDK 再提交。

### 路径 C：Termux 本地编译（要 1.5GB 空间，手机 8GB 内存起）

```bash
pkg update && pkg install -y openjdk-17 gradle wget unzip

# 装 Android 命令行工具
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip && mv cmdline-tools latest

export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin

yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-33" "build-tools;33.0.2"

# 回到工程目录编译
cd ~/VideoStabilizer
echo "sdk.dir=$HOME/android-sdk" > local.properties
./gradlew assembleDebug --no-daemon
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

这条路坑最多：首次同步要下几百 MB，锁屏会被系统杀进程（先 `termux-wake-lock`）；内存小的机器会在 `:app:mergeDexDebug` 阶段被 OOM 杀掉，可以在 `gradle.properties` 里把 `org.gradle.jvmargs` 降到 `-Xmx1536m` 再试。

